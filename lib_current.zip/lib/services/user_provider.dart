import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';

import '../models/app_user.dart';
import 'auth_service.dart';

/// Holds the currently signed-in AppUser (including their role) so
/// any screen can check `context.read<UserProvider>().user?.isBusiness`
/// instead of re-fetching Firestore every time role matters.
///
/// Deliberately tracks TWO separate things:
///   - whether Firebase Auth itself has a signed-in user (fast,
///     reliable — this is what "isSignedIn" means)
///   - whether we've loaded their Firestore profile doc (can lag
///     behind auth by a beat right after signup, or fail/hang if
///     the network is briefly unreachable)
///
/// Collapsing those into one boolean was the bug: a slow or failed
/// profile fetch would read as "not signed in" and silently bounce
/// the user back to the login screen even though their account was
/// perfectly valid. Now a signed-in-but-profile-not-loaded-yet state
/// is its own thing that AuthGate can show a proper loading/retry
/// screen for, instead of either hanging forever or reverting.
class UserProvider extends ChangeNotifier {
  final AuthService _authService;

  User? _firebaseUser;
  AppUser? _user;
  bool _profileLoading = false;
  String? _profileError;

  UserProvider(this._authService) {
    _init();
  }

  AppUser? get user => _user;
  bool get isSignedIn => _firebaseUser != null;
  bool get profileLoading => _profileLoading;
  String? get profileError => _profileError;

  void _init() {
    _authService.authStateChanges.listen((firebaseUser) async {
      _firebaseUser = firebaseUser;
      _user = null;
      _profileError = null;

      if (firebaseUser == null) {
        _profileLoading = false;
        notifyListeners();
        return;
      }

      await _loadProfile();
    });
  }

  Future<void> _loadProfile() async {
    _profileLoading = true;
    _profileError = null;
    notifyListeners();

    try {
      _user = await _authService
          .fetchCurrentAppUser()
          .timeout(const Duration(seconds: 12));
    } catch (e) {
      // Covers both a genuine timeout (network unreachable, as
      // happened on the emulator) and any other Firestore error —
      // either way, surface it so AuthGate can show a Retry button
      // rather than spinning forever.
      _profileError =
          'Could not load your profile. Check your connection and try again.';
    }

    _profileLoading = false;
    notifyListeners();
  }

  /// Call after signup specifically — the Firestore profile doc is
  /// written a moment after the Auth account is created, so the
  /// authStateChanges listener above can sometimes fire and find
  /// nothing yet. This is safe to call without awaiting from the
  /// signup screens (fire-and-forget): AuthGate's loading/retry
  /// screen already handles the "still loading" state gracefully,
  /// so the signup button doesn't need to block on it.
  Future<void> refresh() => _loadProfile();

  /// Manual retry, e.g. from a button on AuthGate's loading screen.
  Future<void> retryLoadProfile() => _loadProfile();

  Future<void> signOut() async {
    await _authService.signOut();
    _firebaseUser = null;
    _user = null;
    notifyListeners();
  }
}
