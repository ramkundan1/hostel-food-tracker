import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/notice.dart';
import '../models/exam_paper.dart';
import '../models/room_listing.dart';
import '../models/restaurant_listing.dart';
import '../models/review.dart';
import '../models/page_result.dart';

/// Every "list" query here is paginated (limit + startAfter) rather
/// than fetching a whole collection. Loading 500 notices at once is
/// exactly the kind of thing that makes an app feel laggy — the UI
/// jank comes from Flutter having to build/measure hundreds of
/// widgets in one frame, not from Firestore itself being slow.
class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  static const int pageSize = 15;

  // ============================================================
  // NOTICES
  // ============================================================

  Future<PageResult<Notice>> fetchNotices({DocumentSnapshot? startAfter}) async {
    Query query = _db
        .collection('notices')
        .orderBy('postedAt', descending: true)
        .limit(pageSize);

    if (startAfter != null) {
      query = query.startAfterDocument(startAfter);
    }

    final snapshot = await query.get();

    final items = snapshot.docs
        .map((doc) => Notice.fromMap(doc.id, doc.data() as Map<String, dynamic>))
        .toList();

    return PageResult(
      items: items,
      lastDoc: snapshot.docs.isEmpty ? null : snapshot.docs.last,
      hasMore: snapshot.docs.length == pageSize,
    );
  }

  Future<void> postNotice(Notice notice) {
    return _db.collection('notices').add(notice.toMap());
  }

  // ============================================================
  // EXAM PAPERS — grouped by exam type, then by date section
  // ============================================================

  /// Returns the distinct exam dates (most recent first) that have
  /// at least one paper of [examType] — this drives the "date-wise
  /// folder" list the user taps into.
  Future<List<DateTime>> fetchExamDateSections(ExamType examType) async {
    final snapshot = await _db
        .collection('examPapers')
        .where('examType', isEqualTo: examTypeToString(examType))
        .orderBy('examDate', descending: true)
        .get();

    final seen = <int>{};
    final dates = <DateTime>[];

    for (final doc in snapshot.docs) {
      final millis = doc.data()['examDate'] as int?;
      if (millis == null) continue;

      final date = DateTime.fromMillisecondsSinceEpoch(millis);
      final dayKey = DateTime(date.year, date.month, date.day).millisecondsSinceEpoch;

      if (seen.add(dayKey)) {
        dates.add(DateTime(date.year, date.month, date.day));
      }
    }

    return dates;
  }

  /// Papers for one specific date section (e.g. everything filed
  /// under "2026-04-12" for Regular exams).
  Future<List<ExamPaper>> fetchExamPapersForDate({
    required ExamType examType,
    required DateTime date,
  }) async {
    final startOfDay = DateTime(date.year, date.month, date.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    final snapshot = await _db
        .collection('examPapers')
        .where('examType', isEqualTo: examTypeToString(examType))
        .where('examDate', isGreaterThanOrEqualTo: startOfDay.millisecondsSinceEpoch)
        .where('examDate', isLessThan: endOfDay.millisecondsSinceEpoch)
        .orderBy('examDate')
        .get();

    return snapshot.docs
        .map((doc) => ExamPaper.fromMap(doc.id, doc.data()))
        .toList();
  }

  Future<void> uploadExamPaperRecord(ExamPaper paper) {
    return _db.collection('examPapers').add(paper.toMap());
  }

  // ============================================================
  // ROOMS
  // ============================================================

  Future<PageResult<RoomListing>> fetchRooms({
    DocumentSnapshot? startAfter,
    bool onlyAvailable = false,
  }) async {
    Query query = _db.collection('rooms');

    if (onlyAvailable) {
      query = query.where('availability', isEqualTo: 'available');
    }

    // Verified listings first, then highest-rated within each
    // group — replaces plain newest-first so trustworthy, popular
    // listings surface at the top instead of just recent ones.
    query = query
        .orderBy('verified', descending: true)
        .orderBy('avgRating', descending: true)
        .limit(pageSize);

    if (startAfter != null) {
      query = query.startAfterDocument(startAfter);
    }

    final snapshot = await query.get();

    final items = snapshot.docs
        .map((doc) => RoomListing.fromMap(doc.id, doc.data() as Map<String, dynamic>))
        .toList();

    return PageResult(
      items: items,
      lastDoc: snapshot.docs.isEmpty ? null : snapshot.docs.last,
      hasMore: snapshot.docs.length == pageSize,
    );
  }

  Future<void> createRoomListing(RoomListing room) {
    return _db.collection('rooms').add(room.toMap());
  }

  /// Same as createRoomListing, but returns the DocumentReference —
  /// used when the screen needs the new doc's ID immediately after
  /// (e.g. to upload photos to `room_photos/{roomId}/...` and then
  /// patch photoUrls back onto the same doc).
  Future<DocumentReference> createRoomListingAndGetRef(RoomListing room) {
    return _db.collection('rooms').add(room.toMap());
  }

  Future<void> updateRoomAvailability(String roomId, RoomAvailability availability) {
    return _db.collection('rooms').doc(roomId).update({
      'availability':
          availability == RoomAvailability.occupied ? 'occupied' : 'available',
    });
  }

  Future<void> setRoomVerified(String roomId, bool verified) {
    return _db.collection('rooms').doc(roomId).update({'verified': verified});
  }

  Stream<List<RoomListing>> myRoomListings(String ownerId) {
    return _db
        .collection('rooms')
        .where('ownerId', isEqualTo: ownerId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) =>
            snap.docs.map((d) => RoomListing.fromMap(d.id, d.data())).toList());
  }

  // ============================================================
  // RESTAURANTS
  // ============================================================

  Future<PageResult<RestaurantListing>> fetchRestaurants({DocumentSnapshot? startAfter}) async {
    // Same verified-then-rating ordering as fetchRooms.
    Query query = _db
        .collection('restaurants')
        .orderBy('verified', descending: true)
        .orderBy('avgRating', descending: true)
        .limit(pageSize);

    if (startAfter != null) {
      query = query.startAfterDocument(startAfter);
    }

    final snapshot = await query.get();

    final items = snapshot.docs
        .map((doc) =>
            RestaurantListing.fromMap(doc.id, doc.data() as Map<String, dynamic>))
        .toList();

    return PageResult(
      items: items,
      lastDoc: snapshot.docs.isEmpty ? null : snapshot.docs.last,
      hasMore: snapshot.docs.length == pageSize,
    );
  }

  Future<void> createRestaurantListing(RestaurantListing restaurant) {
    return _db.collection('restaurants').add(restaurant.toMap());
  }

  Future<DocumentReference> createRestaurantListingAndGetRef(
      RestaurantListing restaurant) {
    return _db.collection('restaurants').add(restaurant.toMap());
  }

  Future<void> setRestaurantVerified(String restaurantId, bool verified) {
    return _db
        .collection('restaurants')
        .doc(restaurantId)
        .update({'verified': verified});
  }

  // ============================================================
  // ADMIN VERIFICATION QUEUE
  // ============================================================

  Future<List<RoomListing>> fetchUnverifiedRooms() async {
    final snapshot = await _db
        .collection('rooms')
        .where('verified', isEqualTo: false)
        .orderBy('createdAt', descending: true)
        .get();

    return snapshot.docs.map((doc) => RoomListing.fromMap(doc.id, doc.data())).toList();
  }

  Future<List<RestaurantListing>> fetchUnverifiedRestaurants() async {
    final snapshot = await _db
        .collection('restaurants')
        .where('verified', isEqualTo: false)
        .orderBy('createdAt', descending: true)
        .get();

    return snapshot.docs
        .map((doc) => RestaurantListing.fromMap(doc.id, doc.data()))
        .toList();
  }

  Future<List<ExamPaper>> fetchUnverifiedExamPapers() async {
    final snapshot = await _db
        .collection('examPapers')
        .where('verified', isEqualTo: false)
        .orderBy('uploadedAt', descending: true)
        .get();

    return snapshot.docs.map((doc) => ExamPaper.fromMap(doc.id, doc.data())).toList();
  }

  Future<void> setExamPaperVerified(String paperId, bool verified) {
    return _db.collection('examPapers').doc(paperId).update({'verified': verified});
  }

  // ============================================================
  // REVIEWS — and keeping avgRating/ratingCount in sync
  // ============================================================

  Future<List<Review>> fetchReviews(ReviewTargetType type, String targetId) async {
    final snapshot = await _db
        .collection('reviews')
        .where('targetType',
            isEqualTo: type == ReviewTargetType.restaurant ? 'restaurant' : 'room')
        .where('targetId', isEqualTo: targetId)
        .orderBy('createdAt', descending: true)
        .get();

    return snapshot.docs.map((doc) => Review.fromMap(doc.id, doc.data())).toList();
  }

  /// Adds a review and atomically recalculates the parent listing's
  /// avgRating/ratingCount inside a transaction, so the two numbers
  /// can never drift out of sync even under concurrent reviews.
  Future<void> submitReview(Review review) async {
    final collectionName =
        review.targetType == ReviewTargetType.restaurant ? 'restaurants' : 'rooms';

    final targetRef = _db.collection(collectionName).doc(review.targetId);
    final reviewRef = _db.collection('reviews').doc();

    await _db.runTransaction((transaction) async {
      final targetSnap = await transaction.get(targetRef);

      final currentCount = (targetSnap.data()?['ratingCount'] ?? 0) as int;
      final currentAvg = ((targetSnap.data()?['avgRating'] ?? 0) as num).toDouble();

      final newCount = currentCount + 1;
      final newAvg = ((currentAvg * currentCount) + review.rating) / newCount;

      transaction.set(reviewRef, review.toMap());
      transaction.update(targetRef, {
        'avgRating': newAvg,
        'ratingCount': newCount,
      });
    });
  }

  // ============================================================
  // GENERAL FEEDBACK
  // ============================================================

  Future<void> submitFeedback({
    required String userId,
    required String userName,
    required String message,
  }) {
    return _db.collection('feedback').add({
      'userId': userId,
      'userName': userName,
      'message': message,
      'createdAt': DateTime.now().millisecondsSinceEpoch,
    });
  }
}
