import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';

import '../models/app_user.dart';

/// Wraps every sign-in method the app supports (Google, Facebook,
/// phone OTP, email/password) behind one simple API, and makes sure
/// a matching `users/{uid}` Firestore document always exists after
/// sign-in — screens can then rely on AppUser.role being available
/// without re-checking auth-provider-specific fields everywhere.
class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  User? get currentFirebaseUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // ============================================================
  // EMAIL / PASSWORD
  // ============================================================

  Future<UserCredential> signUpWithEmail({
    required String name,
    required String email,
    required String password,
    required UserRole role,
  }) async {
    final credential = await _auth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );

    await _ensureUserDocument(
      uid: credential.user!.uid,
      name: name,
      email: email,
      role: role,
    );

    return credential;
  }

  Future<UserCredential> signInWithEmail({
    required String email,
    required String password,
  }) {
    return _auth.signInWithEmailAndPassword(email: email, password: password);
  }

  // ============================================================
  // GOOGLE
  // ============================================================

  Future<UserCredential?> signInWithGoogle({required UserRole role}) async {
    final googleUser = await _googleSignIn.signIn();
    if (googleUser == null) return null; // user cancelled

    final googleAuth = await googleUser.authentication;

    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );

    final userCredential = await _auth.signInWithCredential(credential);

    await _ensureUserDocument(
      uid: userCredential.user!.uid,
      name: userCredential.user!.displayName ?? googleUser.displayName ?? '',
      email: userCredential.user!.email ?? googleUser.email,
      photoUrl: userCredential.user!.photoURL,
      role: role,
    );

    return userCredential;
  }

  // ============================================================
  // FACEBOOK
  // ============================================================

  Future<UserCredential?> signInWithFacebook({required UserRole role}) async {
    final result = await FacebookAuth.instance.login();
    if (result.status != LoginStatus.success || result.accessToken == null) {
      return null;
    }

    final credential =
        FacebookAuthProvider.credential(result.accessToken!.tokenString);

    final userCredential = await _auth.signInWithCredential(credential);

    final fbData = await FacebookAuth.instance.getUserData();

    await _ensureUserDocument(
      uid: userCredential.user!.uid,
      name: userCredential.user!.displayName ?? fbData['name'] ?? '',
      email: userCredential.user!.email ?? fbData['email'] ?? '',
      photoUrl: userCredential.user!.photoURL,
      role: role,
    );

    return userCredential;
  }

  // ============================================================
  // PHONE (OTP)
  // ============================================================

  /// Starts phone verification. `onCodeSent` receives the
  /// verificationId to pass into [confirmPhoneCode] once the user
  /// types the SMS code.
  Future<void> startPhoneSignIn({
    required String phoneNumber,
    required void Function(String verificationId) onCodeSent,
    required void Function(FirebaseAuthException e) onError,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      verificationCompleted: (PhoneAuthCredential credential) async {
        await _auth.signInWithCredential(credential);
      },
      verificationFailed: onError,
      codeSent: (String verificationId, int? resendToken) {
        onCodeSent(verificationId);
      },
      codeAutoRetrievalTimeout: (String verificationId) {},
    );
  }

  Future<UserCredential> confirmPhoneCode({
    required String verificationId,
    required String smsCode,
    required String name,
    required UserRole role,
  }) async {
    final credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: smsCode,
    );

    final userCredential = await _auth.signInWithCredential(credential);

    await _ensureUserDocument(
      uid: userCredential.user!.uid,
      name: name,
      email: userCredential.user!.email ?? '',
      phone: userCredential.user!.phoneNumber,
      role: role,
    );

    return userCredential;
  }

  // ============================================================
  // SHARED
  // ============================================================

  Future<void> signOut() async {
    await Future.wait([
      _auth.signOut(),
      _googleSignIn.signOut(),
      FacebookAuth.instance.logOut(),
    ]);
  }

  Future<AppUser?> fetchCurrentAppUser() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return null;

    final doc = await _db.collection('users').doc(uid).get();
    if (!doc.exists) return null;

    return AppUser.fromMap(uid, doc.data()!);
  }

  /// Only writes the user document the FIRST time (idempotent) —
  /// otherwise every re-login would silently reset the user's role
  /// back to whatever was passed in, which would let someone lose
  /// their "business" role just by logging in again.
  Future<void> _ensureUserDocument({
    required String uid,
    required String name,
    required String email,
    String? phone,
    String? photoUrl,
    required UserRole role,
  }) async {
    final ref = _db.collection('users').doc(uid);
    final existing = await ref.get();

    if (existing.exists) return;

    final user = AppUser(
      uid: uid,
      name: name,
      email: email,
      phone: phone,
      photoUrl: photoUrl,
      role: role,
      createdAt: DateTime.now(),
    );

    await ref.set(user.toMap());
  }
}
