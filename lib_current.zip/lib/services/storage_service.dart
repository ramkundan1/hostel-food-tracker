import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';

/// Every upload goes through here so the storage folder structure
/// stays consistent no matter which screen triggers the upload:
///   exam_papers/{regular|back}/{filename}
///   room_photos/{roomId}/{filename}
///   restaurant_photos/{restaurantId}/{filename}
///   notices/{filename}
class StorageService {
  final FirebaseStorage _storage = FirebaseStorage.instance;

  Future<String> uploadExamPaper({
    required File file,
    required String examTypeFolder, // "regular" or "back"
    required String fileName,
  }) async {
    final ref = _storage.ref('exam_papers/$examTypeFolder/$fileName');
    final task = await ref.putFile(file);
    return task.ref.getDownloadURL();
  }

  Future<String> uploadRoomPhoto({
    required File file,
    required String roomId,
    required String fileName,
  }) async {
    final ref = _storage.ref('room_photos/$roomId/$fileName');
    final task = await ref.putFile(file);
    return task.ref.getDownloadURL();
  }

  Future<String> uploadRestaurantPhoto({
    required File file,
    required String restaurantId,
    required String fileName,
  }) async {
    final ref = _storage.ref('restaurant_photos/$restaurantId/$fileName');
    final task = await ref.putFile(file);
    return task.ref.getDownloadURL();
  }

  Future<String> uploadNoticeFile({
    required File file,
    required String fileName,
  }) async {
    final ref = _storage.ref('notices/$fileName');
    final task = await ref.putFile(file);
    return task.ref.getDownloadURL();
  }
}
