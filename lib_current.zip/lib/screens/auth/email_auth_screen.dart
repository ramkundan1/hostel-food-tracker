import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/app_user.dart';
import '../../services/auth_service.dart';
import '../../services/user_provider.dart';

class EmailAuthScreen extends StatefulWidget {
  final UserRole role;

  const EmailAuthScreen({super.key, required this.role});

  @override
  State<EmailAuthScreen> createState() => _EmailAuthScreenState();
}

class _EmailAuthScreenState extends State<EmailAuthScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  bool _isSignUp = true;
  bool _busy = false;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _busy = true);

    final authService = context.read<AuthService>();

    try {
      if (_isSignUp) {
        await authService.signUpWithEmail(
          name: _nameController.text.trim(),
          email: _emailController.text.trim(),
          password: _passwordController.text,
          role: widget.role,
        );
      } else {
        await authService.signInWithEmail(
          email: _emailController.text.trim(),
          password: _passwordController.text,
        );
      }
      // Explicitly refresh here rather than relying solely on the
      // auth-state stream in UserProvider: signUpWithEmail already
      // awaits creating the Firestore user doc before returning,
      // but Firebase's authStateChanges can fire (and UserProvider
      // can try to read that doc) the instant the auth ACCOUNT is
      // created — before the doc write finishes. If that race
      // loses, UserProvider settles on "signed out" and nothing
      // ever re-checks, leaving the user stuck on the welcome
      // screen despite a valid account existing. Calling refresh()
      // here happens only after we're certain the doc exists.
      // Fire-and-forget: don't block the button on a Firestore
      // round-trip. AuthGate already shows a loading/retry screen
      // driven by the auth-state stream — this is just a helpful
      // nudge in case the stream's own attempt fired before the
      // signup doc write finished.
      if (mounted) {
        context.read<UserProvider>().refresh();

        // Pop this pushed screen (and the WelcomeScreen beneath it,
        // if it's also on the stack) so AuthGate's current build —
        // which will show HomeShell once signed in — is actually
        // visible instead of sitting hidden underneath this screen.
        // Without this, login visibly "does nothing" even though it
        // succeeded, and only the back button reveals the app.
        Navigator.of(context).popUntil((route) => route.isFirst);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(_friendlyError(e))));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _friendlyError(Object e) {
    final message = e.toString();
    if (message.contains('email-already-in-use')) {
      return 'That email is already registered — try logging in instead.';
    }
    if (message.contains('weak-password')) {
      return 'Password should be at least 6 characters.';
    }
    if (message.contains('user-not-found') || message.contains('wrong-password')) {
      return 'Incorrect email or password.';
    }
    return 'Something went wrong. Please try again.';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isSignUp ? 'Create Account' : 'Log In')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (_isSignUp) ...[
                  TextFormField(
                    controller: _nameController,
                    decoration: const InputDecoration(labelText: 'Full name'),
                    validator: (v) =>
                        (v == null || v.trim().isEmpty) ? 'Enter your name' : null,
                  ),
                  const SizedBox(height: 14),
                ],
                TextFormField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(labelText: 'Email'),
                  validator: (v) => (v == null || !v.contains('@'))
                      ? 'Enter a valid email'
                      : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'Password'),
                  validator: (v) => (v == null || v.length < 6)
                      ? 'At least 6 characters'
                      : null,
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _busy ? null : _submit,
                  child: _busy
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : Text(_isSignUp ? 'Create Account' : 'Log In'),
                ),
                const SizedBox(height: 16),
                TextButton(
                  onPressed: _busy ? null : () => setState(() => _isSignUp = !_isSignUp),
                  child: Text(
                    _isSignUp
                        ? 'Already have an account? Log in'
                        : "Don't have an account? Sign up",
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
