import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/app_user.dart';
import '../../services/auth_service.dart';
import '../../services/user_provider.dart';
import '../../theme/app_theme.dart';
import 'email_auth_screen.dart';
import 'phone_auth_screen.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  UserRole _selectedRole = UserRole.student;
  bool _busy = false;

  Future<void> _runSocialSignIn(Future<void> Function() action) async {
    setState(() => _busy = true);
    try {
      await action();
      // Same race-condition fix as email/phone signup — force a
      // refresh now that we're certain the Firestore user doc
      // exists (both Google and Facebook sign-in await creating
      // it before returning).
      // Fire-and-forget — see the note in email_auth_screen.dart.
      if (mounted) {
        context.read<UserProvider>().refresh();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Sign-in failed: $e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final authService = context.read<AuthService>();

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            children: [
              const Spacer(),
              Container(
                width: 84,
                height: 84,
                decoration: BoxDecoration(
                  color: AppTheme.primary,
                  borderRadius: BorderRadius.circular(22),
                ),
                child: const Icon(Icons.school_rounded,
                    color: Colors.white, size: 44),
              ),
              const SizedBox(height: 20),
              Text('Campus Connect',
                  style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 8),
              Text(
                'Notices, past papers, rooms & food —\nall in one place.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 36),

              // ---- Role toggle ----
              Text('Continue as', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: _RoleChip(
                      label: 'Student',
                      icon: Icons.backpack_rounded,
                      selected: _selectedRole == UserRole.student,
                      onTap: () => setState(() => _selectedRole = UserRole.student),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _RoleChip(
                      label: 'Business',
                      icon: Icons.storefront_rounded,
                      selected: _selectedRole == UserRole.business,
                      onTap: () => setState(() => _selectedRole = UserRole.business),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 28),

              // ---- Sign-in methods ----
              _SignInButton(
                icon: Icons.g_mobiledata_rounded,
                label: 'Continue with Google',
                busy: _busy,
                onPressed: () => _runSocialSignIn(
                  () => authService.signInWithGoogle(role: _selectedRole),
                ),
              ),
              const SizedBox(height: 12),
              _SignInButton(
                icon: Icons.facebook_rounded,
                label: 'Continue with Facebook',
                busy: _busy,
                onPressed: () => _runSocialSignIn(
                  () => authService.signInWithFacebook(role: _selectedRole),
                ),
              ),
              const SizedBox(height: 12),
              _SignInButton(
                icon: Icons.phone_rounded,
                label: 'Continue with Phone',
                busy: _busy,
                onPressed: _busy
                    ? null
                    : () => Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => PhoneAuthScreen(role: _selectedRole),
                          ),
                        ),
              ),
              const SizedBox(height: 12),
              _SignInButton(
                icon: Icons.email_rounded,
                label: 'Continue with Email',
                busy: _busy,
                onPressed: _busy
                    ? null
                    : () => Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => EmailAuthScreen(role: _selectedRole),
                          ),
                        ),
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }
}

class _RoleChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _RoleChip({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: selected ? AppTheme.primary : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? AppTheme.primary : const Color(0xFFD0D5DD),
          ),
        ),
        child: Column(
          children: [
            Icon(icon, color: selected ? Colors.white : AppTheme.textSecondary),
            const SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(
                color: selected ? Colors.white : AppTheme.textPrimary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SignInButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool busy;
  final VoidCallback? onPressed;

  const _SignInButton({
    required this.icon,
    required this.label,
    required this.busy,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      onPressed: busy ? null : onPressed,
      icon: Icon(icon),
      label: Text(label),
    );
  }
}
