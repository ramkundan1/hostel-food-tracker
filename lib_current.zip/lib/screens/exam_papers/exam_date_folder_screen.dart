import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../models/exam_paper.dart';
import '../../services/firestore_service.dart';
import '../../theme/app_theme.dart';

class ExamDateFolderScreen extends StatefulWidget {
  final ExamType examType;
  final DateTime date;

  const ExamDateFolderScreen({
    super.key,
    required this.examType,
    required this.date,
  });

  @override
  State<ExamDateFolderScreen> createState() => _ExamDateFolderScreenState();
}

class _ExamDateFolderScreenState extends State<ExamDateFolderScreen> {
  late Future<List<ExamPaper>> _papersFuture;

  @override
  void initState() {
    super.initState();
    _papersFuture = context.read<FirestoreService>().fetchExamPapersForDate(
          examType: widget.examType,
          date: widget.date,
        );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(DateFormat('MMMM d, yyyy').format(widget.date)),
      ),
      body: FutureBuilder<List<ExamPaper>>(
        future: _papersFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final papers = snapshot.data ?? [];

          if (papers.isEmpty) {
            return const Center(child: Text('No papers found for this date.'));
          }

          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: papers.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final paper = papers[index];

              return Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  leading: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppTheme.secondary.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.picture_as_pdf_rounded,
                        color: AppTheme.secondary),
                  ),
                  title: Text(paper.subject, style: Theme.of(context).textTheme.titleMedium),
                  subtitle: Text('Semester ${paper.semester}'),
                  trailing: !paper.verified
                      ? Tooltip(
                          message: 'Pending admin verification',
                          child: Icon(Icons.hourglass_top_rounded,
                              color: Colors.grey.shade400, size: 18),
                        )
                      : const Icon(Icons.download_rounded, color: AppTheme.primary),
                  onTap: () => launchUrl(Uri.parse(paper.fileUrl)),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
