import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../models/exam_paper.dart';
import '../../services/firestore_service.dart';
import '../../services/user_provider.dart';
import '../../theme/app_theme.dart';
import 'exam_date_folder_screen.dart';
import 'upload_exam_paper_screen.dart';

class ExamPapersScreen extends StatefulWidget {
  const ExamPapersScreen({super.key});

  @override
  State<ExamPapersScreen> createState() => _ExamPapersScreenState();
}

class _ExamPapersScreenState extends State<ExamPapersScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Exam Papers'),
        bottom: TabBar(
          controller: _tabController,
          labelColor: AppTheme.primary,
          unselectedLabelColor: AppTheme.textSecondary,
          indicatorColor: AppTheme.primary,
          tabs: const [
            Tab(text: 'Regular'),
            Tab(text: 'Back Exam'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [
          _DateFolderList(examType: ExamType.regular),
          _DateFolderList(examType: ExamType.back),
        ],
      ),
      floatingActionButton: (context.watch<UserProvider>().user?.isAdmin ?? false)
          ? FloatingActionButton.extended(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => UploadExamPaperScreen(
                    initialExamType: _tabController.index == 0
                        ? ExamType.regular
                        : ExamType.back,
                  ),
                ),
              ),
              icon: const Icon(Icons.upload_file_rounded),
              label: const Text('Upload'),
            )
          : null,
    );
  }
}

class _DateFolderList extends StatefulWidget {
  final ExamType examType;

  const _DateFolderList({required this.examType});

  @override
  State<_DateFolderList> createState() => _DateFolderListState();
}

class _DateFolderListState extends State<_DateFolderList>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  late Future<List<DateTime>> _datesFuture;

  @override
  void initState() {
    super.initState();
    _datesFuture =
        context.read<FirestoreService>().fetchExamDateSections(widget.examType);
  }

  Future<void> _refresh() async {
    setState(() {
      _datesFuture =
          context.read<FirestoreService>().fetchExamDateSections(widget.examType);
    });
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    return RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<List<DateTime>>(
        future: _datesFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final dates = snapshot.data ?? [];

          if (dates.isEmpty) {
            return ListView(
              children: [
                const SizedBox(height: 140),
                Icon(Icons.folder_off_rounded, size: 40, color: Colors.grey.shade400),
                const SizedBox(height: 12),
                Center(
                  child: Text(
                    'No papers uploaded yet.',
                    style: TextStyle(color: Colors.grey.shade600),
                  ),
                ),
              ],
            );
          }

          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: dates.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final date = dates[index];

              return Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  leading: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppTheme.primary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.folder_rounded, color: AppTheme.primary),
                  ),
                  title: Text(DateFormat('MMMM d, yyyy').format(date),
                      style: Theme.of(context).textTheme.titleMedium),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => ExamDateFolderScreen(
                        examType: widget.examType,
                        date: date,
                      ),
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
