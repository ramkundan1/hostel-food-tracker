import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../models/exam_paper.dart';
import '../../services/firestore_service.dart';
import '../../services/storage_service.dart';

class UploadExamPaperScreen extends StatefulWidget {
  final ExamType initialExamType;

  const UploadExamPaperScreen({super.key, required this.initialExamType});

  @override
  State<UploadExamPaperScreen> createState() => _UploadExamPaperScreenState();
}

class _UploadExamPaperScreenState extends State<UploadExamPaperScreen> {
  final _formKey = GlobalKey<FormState>();
  final _subjectController = TextEditingController();
  final _semesterController = TextEditingController();

  late ExamType _examType;
  DateTime _examDate = DateTime.now();
  File? _pickedFile;
  String? _pickedFileName;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _examType = widget.initialExamType;
  }

  @override
  void dispose() {
    _subjectController.dispose();
    _semesterController.dispose();
    super.dispose();
  }

  Future<void> _pickFile() async {
    final files = await FilePicker.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );
    if (files.isEmpty || files.first.path == null) return;

    setState(() {
      _pickedFile = File(files.first.path!);
      _pickedFileName = files.first.name;
    });
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _examDate,
      firstDate: DateTime(2018),
      lastDate: DateTime.now().add(const Duration(days: 30)),
    );
    if (picked != null) setState(() => _examDate = picked);
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    if (_pickedFile == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Please attach a PDF')));
      return;
    }

    setState(() => _busy = true);

    try {
      final storageService = context.read<StorageService>();
      final firestoreService = context.read<FirestoreService>();

      final examTypeFolder = examTypeToString(_examType);
      final safeFileName =
          '${DateTime.now().millisecondsSinceEpoch}_$_pickedFileName';

      final fileUrl = await storageService.uploadExamPaper(
        file: _pickedFile!,
        examTypeFolder: examTypeFolder,
        fileName: safeFileName,
      );

      await firestoreService.uploadExamPaperRecord(
        ExamPaper(
          id: '',
          examType: _examType,
          examDate: _examDate,
          subject: _subjectController.text.trim(),
          semester: _semesterController.text.trim(),
          fileUrl: fileUrl,
          fileName: _pickedFileName!,
          verified: true,
          uploadedAt: DateTime.now(),
        ),
      );

      if (mounted) {
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Paper uploaded and published.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Upload failed: $e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Upload Exam Paper')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SegmentedButton<ExamType>(
                  segments: const [
                    ButtonSegment(value: ExamType.regular, label: Text('Regular')),
                    ButtonSegment(value: ExamType.back, label: Text('Back Exam')),
                  ],
                  selected: {_examType},
                  onSelectionChanged: (selection) =>
                      setState(() => _examType = selection.first),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _subjectController,
                  decoration: const InputDecoration(labelText: 'Subject'),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _semesterController,
                  decoration: const InputDecoration(labelText: 'Semester'),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                ),
                const SizedBox(height: 14),
                InkWell(
                  onTap: _pickDate,
                  child: InputDecorator(
                    decoration: const InputDecoration(labelText: 'Exam date'),
                    child: Text(DateFormat('MMMM d, yyyy').format(_examDate)),
                  ),
                ),
                const SizedBox(height: 14),
                OutlinedButton.icon(
                  onPressed: _pickFile,
                  icon: const Icon(Icons.picture_as_pdf_rounded),
                  label: Text(_pickedFileName ?? 'Attach PDF'),
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _busy ? null : _submit,
                  child: _busy
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white),
                        )
                      : const Text('Upload'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
