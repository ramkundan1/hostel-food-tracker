import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/exam_paper.dart';
import '../../models/restaurant_listing.dart';
import '../../models/room_listing.dart';
import '../../services/firestore_service.dart';
import '../../theme/app_theme.dart';

class VerificationQueueScreen extends StatefulWidget {
  const VerificationQueueScreen({super.key});

  @override
  State<VerificationQueueScreen> createState() => _VerificationQueueScreenState();
}

class _VerificationQueueScreenState extends State<VerificationQueueScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Verification Queue'),
        bottom: TabBar(
          controller: _tabController,
          labelColor: AppTheme.primary,
          unselectedLabelColor: AppTheme.textSecondary,
          indicatorColor: AppTheme.primary,
          isScrollable: true,
          tabs: const [
            Tab(text: 'Rooms'),
            Tab(text: 'Restaurants'),
            Tab(text: 'Exam Papers'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [
          _PendingRooms(),
          _PendingRestaurants(),
          _PendingExamPapers(),
        ],
      ),
    );
  }
}

class _PendingRooms extends StatefulWidget {
  const _PendingRooms();

  @override
  State<_PendingRooms> createState() => _PendingRoomsState();
}

class _PendingRoomsState extends State<_PendingRooms> {
  late Future<List<RoomListing>> _future;

  @override
  void initState() {
    super.initState();
    _future = context.read<FirestoreService>().fetchUnverifiedRooms();
  }

  Future<void> _approve(RoomListing room) async {
    await context.read<FirestoreService>().setRoomVerified(room.id, true);
    setState(() => _future = context.read<FirestoreService>().fetchUnverifiedRooms());
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<RoomListing>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        final rooms = snapshot.data ?? [];
        if (rooms.isEmpty) return const _EmptyQueue();

        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: rooms.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, index) {
            final room = rooms[index];
            return _QueueCard(
              title: room.title,
              subtitle:
                  '${room.address} — Rs. ${room.price.toStringAsFixed(0)}/mo\nOwner: ${room.ownerName} (${room.ownerPhone})',
              onApprove: () => _approve(room),
            );
          },
        );
      },
    );
  }
}

class _PendingRestaurants extends StatefulWidget {
  const _PendingRestaurants();

  @override
  State<_PendingRestaurants> createState() => _PendingRestaurantsState();
}

class _PendingRestaurantsState extends State<_PendingRestaurants> {
  late Future<List<RestaurantListing>> _future;

  @override
  void initState() {
    super.initState();
    _future = context.read<FirestoreService>().fetchUnverifiedRestaurants();
  }

  Future<void> _approve(RestaurantListing restaurant) async {
    await context.read<FirestoreService>().setRestaurantVerified(restaurant.id, true);
    setState(() =>
        _future = context.read<FirestoreService>().fetchUnverifiedRestaurants());
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<RestaurantListing>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        final restaurants = snapshot.data ?? [];
        if (restaurants.isEmpty) return const _EmptyQueue();

        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: restaurants.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, index) {
            final restaurant = restaurants[index];
            return _QueueCard(
              title: restaurant.name,
              subtitle: '${restaurant.address}\nPhone: ${restaurant.phone}',
              onApprove: () => _approve(restaurant),
            );
          },
        );
      },
    );
  }
}

class _PendingExamPapers extends StatefulWidget {
  const _PendingExamPapers();

  @override
  State<_PendingExamPapers> createState() => _PendingExamPapersState();
}

class _PendingExamPapersState extends State<_PendingExamPapers> {
  late Future<List<ExamPaper>> _future;

  @override
  void initState() {
    super.initState();
    _future = context.read<FirestoreService>().fetchUnverifiedExamPapers();
  }

  Future<void> _approve(ExamPaper paper) async {
    await context.read<FirestoreService>().setExamPaperVerified(paper.id, true);
    setState(() =>
        _future = context.read<FirestoreService>().fetchUnverifiedExamPapers());
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<ExamPaper>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        final papers = snapshot.data ?? [];
        if (papers.isEmpty) return const _EmptyQueue();

        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: papers.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, index) {
            final paper = papers[index];
            return _QueueCard(
              title: '${paper.subject} — Semester ${paper.semester}',
              subtitle:
                  '${examTypeToString(paper.examType).toUpperCase()} exam · ${paper.fileName}',
              onApprove: () => _approve(paper),
            );
          },
        );
      },
    );
  }
}

class _QueueCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final VoidCallback onApprove;

  const _QueueCard({
    required this.title,
    required this.subtitle,
    required this.onApprove,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 6),
            Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerRight,
              child: ElevatedButton.icon(
                onPressed: onApprove,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.success,
                  minimumSize: const Size(0, 40),
                ),
                icon: const Icon(Icons.check_rounded, size: 18),
                label: const Text('Approve'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyQueue extends StatelessWidget {
  const _EmptyQueue();

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        const SizedBox(height: 140),
        Icon(Icons.task_alt_rounded, size: 40, color: Colors.grey.shade400),
        const SizedBox(height: 12),
        Center(
          child: Text('All caught up!', style: TextStyle(color: Colors.grey.shade600)),
        ),
      ],
    );
  }
}
