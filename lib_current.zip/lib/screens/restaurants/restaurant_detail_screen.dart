import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../models/restaurant_listing.dart';
import '../../models/review.dart';
import '../../services/firestore_service.dart';
import '../../services/user_provider.dart';
import '../../theme/app_theme.dart';
import '../../widgets/rating_stars.dart';
import '../../widgets/section_header.dart';

class RestaurantDetailScreen extends StatefulWidget {
  final RestaurantListing restaurant;

  const RestaurantDetailScreen({super.key, required this.restaurant});

  @override
  State<RestaurantDetailScreen> createState() => _RestaurantDetailScreenState();
}

class _RestaurantDetailScreenState extends State<RestaurantDetailScreen> {
  List<Review> _reviews = [];
  bool _loadingReviews = true;

  @override
  void initState() {
    super.initState();
    _loadReviews();
  }

  Future<void> _loadReviews() async {
    final reviews = await context
        .read<FirestoreService>()
        .fetchReviews(ReviewTargetType.restaurant, widget.restaurant.id);

    if (mounted) {
      setState(() {
        _reviews = reviews;
        _loadingReviews = false;
      });
    }
  }

  void _openReviewSheet() {
    final user = context.read<UserProvider>().user;
    if (user == null) return;

    double rating = 4;
    final commentController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetContext) {
        return Padding(
          padding: EdgeInsets.only(
            left: 20,
            right: 20,
            top: 20,
            bottom: MediaQuery.of(sheetContext).viewInsets.bottom + 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Rate the food quality', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 12),
              Center(
                child: RatingBar.builder(
                  initialRating: rating,
                  minRating: 1,
                  itemSize: 34,
                  itemBuilder: (_, __) =>
                      const Icon(Icons.star_rounded, color: Colors.amber),
                  onRatingUpdate: (value) => rating = value,
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: commentController,
                maxLines: 3,
                decoration: const InputDecoration(hintText: 'How was the food & service?'),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () async {
                  await context.read<FirestoreService>().submitReview(
                        Review(
                          id: '',
                          targetType: ReviewTargetType.restaurant,
                          targetId: widget.restaurant.id,
                          userId: user.uid,
                          userName: user.name,
                          rating: rating,
                          comment: commentController.text.trim(),
                          createdAt: DateTime.now(),
                        ),
                      );
                  if (context.mounted) Navigator.of(sheetContext).pop();
                  _loadReviews();
                },
                child: const Text('Submit Review'),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final restaurant = widget.restaurant;

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 220,
            pinned: true,
            backgroundColor: AppTheme.background,
            foregroundColor: AppTheme.textPrimary,
            flexibleSpace: FlexibleSpaceBar(
              background: restaurant.photoUrls.isNotEmpty
                  ? PageView(
                      children: restaurant.photoUrls
                          .map((url) => CachedNetworkImage(
                                imageUrl: url,
                                fit: BoxFit.cover,
                                placeholder: (_, __) =>
                                    Container(color: Colors.grey.shade200),
                              ))
                          .toList(),
                    )
                  : Container(
                      color: Colors.grey.shade200,
                      child: const Icon(Icons.restaurant_rounded,
                          size: 60, color: Colors.grey),
                    ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(restaurant.name,
                            style: Theme.of(context).textTheme.headlineSmall),
                      ),
                      if (restaurant.verified)
                        const Icon(Icons.verified_rounded, color: AppTheme.primary),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(restaurant.address, style: Theme.of(context).textTheme.bodyMedium),
                  const SizedBox(height: 12),
                  RatingStars(
                      rating: restaurant.avgRating,
                      count: restaurant.ratingCount,
                      size: 18),
                  if (restaurant.cuisineTags.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: restaurant.cuisineTags
                          .map((tag) => Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 5),
                                decoration: BoxDecoration(
                                  color: AppTheme.secondary.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Text(
                                  tag,
                                  style: const TextStyle(
                                    color: AppTheme.secondary,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 12.5,
                                  ),
                                ),
                              ))
                          .toList(),
                    ),
                  ],
                  const SizedBox(height: 24),
                  SectionHeader(
                    icon: Icons.info_rounded,
                    label: 'About',
                    color: AppTheme.primary,
                  ),
                  const SizedBox(height: 10),
                  Text(restaurant.description, style: Theme.of(context).textTheme.bodyMedium),
                  const SizedBox(height: 24),
                  OutlinedButton.icon(
                    onPressed: () => launchUrl(Uri.parse('tel:${restaurant.phone}')),
                    icon: const Icon(Icons.call_rounded),
                    label: const Text('Call to reserve / order'),
                  ),
                  const SizedBox(height: 28),
                  Row(
                    children: [
                      SectionHeader(
                        icon: Icons.reviews_rounded,
                        label: 'Reviews',
                        color: AppTheme.secondary,
                      ),
                      const Spacer(),
                      TextButton(
                        onPressed: _openReviewSheet,
                        child: const Text('Write a review'),
                      ),
                    ],
                  ),
                  if (_loadingReviews)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 20),
                      child: Center(child: CircularProgressIndicator()),
                    )
                  else if (_reviews.isEmpty)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      child: Text('No reviews yet — be the first.',
                          style: Theme.of(context).textTheme.bodyMedium),
                    )
                  else
                    ..._reviews.map((review) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Text(review.userName,
                                      style: Theme.of(context).textTheme.titleMedium),
                                  const SizedBox(width: 8),
                                  RatingStars(rating: review.rating, count: 1, size: 14),
                                ],
                              ),
                              if (review.comment.isNotEmpty) ...[
                                const SizedBox(height: 4),
                                Text(review.comment,
                                    style: Theme.of(context).textTheme.bodyMedium),
                              ],
                            ],
                          ),
                        )),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
