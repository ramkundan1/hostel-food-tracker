import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../models/restaurant_listing.dart';
import '../../services/firestore_service.dart';
import '../../services/storage_service.dart';
import '../../services/user_provider.dart';

class AddRestaurantScreen extends StatefulWidget {
  const AddRestaurantScreen({super.key});

  @override
  State<AddRestaurantScreen> createState() => _AddRestaurantScreenState();
}

class _AddRestaurantScreenState extends State<AddRestaurantScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _addressController = TextEditingController();
  final _phoneController = TextEditingController();
  final _cuisineController = TextEditingController();

  final List<File> _photos = [];
  bool _busy = false;

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _addressController.dispose();
    _phoneController.dispose();
    _cuisineController.dispose();
    super.dispose();
  }

  Future<void> _pickPhotos() async {
    final picker = ImagePicker();
    final picked = await picker.pickMultiImage(imageQuality: 80);
    if (picked.isEmpty) return;
    setState(() => _photos.addAll(picked.map((x) => File(x.path))));
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _busy = true);

    try {
      final user = context.read<UserProvider>().user!;
      final firestoreService = context.read<FirestoreService>();
      final storageService = context.read<StorageService>();

      final restaurant = RestaurantListing(
        id: '',
        ownerId: user.uid,
        name: _nameController.text.trim(),
        description: _descriptionController.text.trim(),
        address: _addressController.text.trim(),
        phone: _phoneController.text.trim(),
        photoUrls: const [],
        cuisineTags: _cuisineController.text
            .split(',')
            .map((s) => s.trim())
            .where((s) => s.isNotEmpty)
            .toList(),
        // Admin-created listings publish immediately verified —
        // same reasoning as exam papers: the creator IS the
        // verifier. Business-created listings still go through
        // the normal pending-approval queue.
        verified: user.isAdmin,
        avgRating: 0,
        ratingCount: 0,
        createdAt: DateTime.now(),
      );

      final docRef =
          await firestoreService.createRestaurantListingAndGetRef(restaurant);

      if (_photos.isNotEmpty) {
        final urls = <String>[];
        for (int i = 0; i < _photos.length; i++) {
          final url = await storageService.uploadRestaurantPhoto(
            file: _photos[i],
            restaurantId: docRef.id,
            fileName: 'photo_$i.jpg',
          );
          urls.add(url);
        }
        await docRef.update({'photoUrls': urls});
      }

      if (mounted) {
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              user.isAdmin
                  ? 'Listed and published!'
                  : 'Listed! It\'ll show as "Unverified" until an admin approves it.',
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Failed to list restaurant: $e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('List a Restaurant')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(labelText: 'Restaurant name'),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _descriptionController,
                  maxLines: 4,
                  decoration: const InputDecoration(labelText: 'Description'),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _addressController,
                  decoration: const InputDecoration(labelText: 'Address / landmark'),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _phoneController,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(labelText: 'Contact phone'),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _cuisineController,
                  decoration: const InputDecoration(
                    labelText: 'Cuisine tags (comma separated)',
                    hintText: 'Newari, Momo, Fast Food',
                  ),
                ),
                const SizedBox(height: 20),
                OutlinedButton.icon(
                  onPressed: _pickPhotos,
                  icon: const Icon(Icons.add_photo_alternate_rounded),
                  label: Text(_photos.isEmpty
                      ? 'Add Photos'
                      : '${_photos.length} photo(s) selected'),
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _busy ? null : _submit,
                  child: _busy
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white),
                        )
                      : const Text('Submit Listing'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
