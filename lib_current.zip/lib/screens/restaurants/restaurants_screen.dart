import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/restaurant_listing.dart';
import '../../services/firestore_service.dart';
import '../../services/user_provider.dart';
import '../../theme/app_theme.dart';
import '../../widgets/paginated_list_view.dart';
import '../../widgets/rating_stars.dart';
import 'add_restaurant_screen.dart';
import 'restaurant_detail_screen.dart';

class RestaurantsScreen extends StatelessWidget {
  const RestaurantsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final firestoreService = context.read<FirestoreService>();
    final user = context.watch<UserProvider>().user;

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(title: const Text('Restaurants')),
      body: PaginatedListView<RestaurantListing>(
        emptyMessage: 'No restaurants listed yet.',
        fetchPage: (startAfter) =>
            firestoreService.fetchRestaurants(startAfter: startAfter),
        itemBuilder: (context, restaurant) => _RestaurantCard(restaurant: restaurant),
      ),
      floatingActionButton: ((user?.isBusiness ?? false) || (user?.isAdmin ?? false))
          ? FloatingActionButton.extended(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const AddRestaurantScreen()),
              ),
              icon: const Icon(Icons.add_rounded),
              label: const Text('List Restaurant'),
            )
          : null,
    );
  }
}

class _RestaurantCard extends StatelessWidget {
  final RestaurantListing restaurant;

  const _RestaurantCard({required this.restaurant});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFEAECF0)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => RestaurantDetailScreen(restaurant: restaurant),
          ),
        ),
        child: IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(
                width: 104,
                child: restaurant.photoUrls.isNotEmpty
                    ? CachedNetworkImage(
                        imageUrl: restaurant.photoUrls.first,
                        fit: BoxFit.cover,
                        placeholder: (_, __) => Container(color: Colors.grey.shade200),
                        errorWidget: (_, __, ___) => Container(
                          color: Colors.grey.shade100,
                          child: Icon(Icons.restaurant_rounded,
                              color: Colors.grey.shade300, size: 30),
                        ),
                      )
                    : Container(
                        color: Colors.grey.shade100,
                        child: Icon(Icons.restaurant_rounded,
                            color: Colors.grey.shade300, size: 30),
                      ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(restaurant.name,
                                style: Theme.of(context).textTheme.titleMedium),
                          ),
                          if (restaurant.verified) ...[
                            const SizedBox(width: 4),
                            const Icon(Icons.verified_rounded,
                                color: AppTheme.primary, size: 16),
                          ],
                        ],
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Icon(Icons.place_rounded, size: 12, color: Colors.grey.shade500),
                          const SizedBox(width: 3),
                          Expanded(
                            child: Text(
                              restaurant.address,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: Theme.of(context).textTheme.bodyMedium,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      RatingStars(rating: restaurant.avgRating, count: restaurant.ratingCount),
                      if (restaurant.cuisineTags.isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: restaurant.cuisineTags
                              .take(3)
                              .map((tag) => Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: AppTheme.secondary.withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Text(
                                      tag,
                                      style: const TextStyle(
                                        fontSize: 11,
                                        color: AppTheme.secondary,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ))
                              .toList(),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
