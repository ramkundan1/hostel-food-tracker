import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../models/room_listing.dart';
import '../../services/firestore_service.dart';
import '../../services/storage_service.dart';
import '../../services/user_provider.dart';

class AddRoomScreen extends StatefulWidget {
  const AddRoomScreen({super.key});

  @override
  State<AddRoomScreen> createState() => _AddRoomScreenState();
}

class _AddRoomScreenState extends State<AddRoomScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _priceController = TextEditingController();
  final _addressController = TextEditingController();
  final _phoneController = TextEditingController();

  bool _water = false;
  bool _internet = false;
  bool _bathroom = false;
  bool _kitchen = false;
  bool _parking = false;
  bool _electricity = false;

  final List<File> _photos = [];
  bool _busy = false;

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _priceController.dispose();
    _addressController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _pickPhotos() async {
    final picker = ImagePicker();
    final picked = await picker.pickMultiImage(imageQuality: 80);
    if (picked.isEmpty) return;

    setState(() {
      _photos.addAll(picked.map((x) => File(x.path)));
    });
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _busy = true);

    try {
      final user = context.read<UserProvider>().user!;
      final firestoreService = context.read<FirestoreService>();
      final storageService = context.read<StorageService>();

      // Firestore needs the doc's own ID to organize the photo
      // storage path, so create the doc first with no photos,
      // then upload photos and patch the URLs in.
      final room = RoomListing(
        id: '',
        ownerId: user.uid,
        ownerName: user.name,
        ownerPhone: _phoneController.text.trim(),
        title: _titleController.text.trim(),
        description: _descriptionController.text.trim(),
        price: double.tryParse(_priceController.text.trim()) ?? 0,
        address: _addressController.text.trim(),
        photoUrls: const [],
        amenities: RoomAmenities(
          water: _water,
          internet: _internet,
          attachedBathroom: _bathroom,
          kitchen: _kitchen,
          parking: _parking,
          electricityIncluded: _electricity,
        ),
        availability: RoomAvailability.available,
        // Admin-created listings publish immediately verified —
        // same reasoning as exam papers: the creator IS the
        // verifier. Business-created listings still go through
        // the normal pending-approval queue.
        verified: user.isAdmin,
        avgRating: 0,
        ratingCount: 0,
        createdAt: DateTime.now(),
      );

      final docRef = await firestoreService.createRoomListingAndGetRef(room);

      if (_photos.isNotEmpty) {
        final urls = <String>[];
        for (int i = 0; i < _photos.length; i++) {
          final url = await storageService.uploadRoomPhoto(
            file: _photos[i],
            roomId: docRef.id,
            fileName: 'photo_$i.jpg',
          );
          urls.add(url);
        }
        await docRef.update({'photoUrls': urls});
      }

      if (mounted) {
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              user.isAdmin
                  ? 'Listed and published!'
                  : 'Listed! It\'ll show as "Unverified" until an admin approves it.',
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Failed to list room: $e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('List a Room')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextFormField(
                  controller: _titleController,
                  decoration: const InputDecoration(labelText: 'Title (e.g. "2BHK near main gate")'),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _descriptionController,
                  maxLines: 4,
                  decoration: const InputDecoration(labelText: 'Description'),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _priceController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Monthly rent (Rs.)'),
                  validator: (v) =>
                      (v == null || double.tryParse(v.trim()) == null) ? 'Enter a valid number' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _addressController,
                  decoration: const InputDecoration(labelText: 'Address / landmark'),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _phoneController,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(labelText: 'Contact phone'),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                ),
                const SizedBox(height: 20),
                Text('Amenities', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 4),
                _AmenityCheckbox(
                  label: 'Water supply',
                  value: _water,
                  onChanged: (v) => setState(() => _water = v),
                ),
                _AmenityCheckbox(
                  label: 'Internet',
                  value: _internet,
                  onChanged: (v) => setState(() => _internet = v),
                ),
                _AmenityCheckbox(
                  label: 'Attached bathroom',
                  value: _bathroom,
                  onChanged: (v) => setState(() => _bathroom = v),
                ),
                _AmenityCheckbox(
                  label: 'Kitchen',
                  value: _kitchen,
                  onChanged: (v) => setState(() => _kitchen = v),
                ),
                _AmenityCheckbox(
                  label: 'Parking',
                  value: _parking,
                  onChanged: (v) => setState(() => _parking = v),
                ),
                _AmenityCheckbox(
                  label: 'Electricity included',
                  value: _electricity,
                  onChanged: (v) => setState(() => _electricity = v),
                ),
                const SizedBox(height: 20),
                OutlinedButton.icon(
                  onPressed: _pickPhotos,
                  icon: const Icon(Icons.add_photo_alternate_rounded),
                  label: Text(_photos.isEmpty
                      ? 'Add Photos'
                      : '${_photos.length} photo(s) selected'),
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _busy ? null : _submit,
                  child: _busy
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white),
                        )
                      : const Text('Submit Listing'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _AmenityCheckbox extends StatelessWidget {
  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _AmenityCheckbox({
    required this.label,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return CheckboxListTile(
      value: value,
      onChanged: (v) => onChanged(v ?? false),
      title: Text(label),
      controlAffinity: ListTileControlAffinity.leading,
      contentPadding: EdgeInsets.zero,
      dense: true,
    );
  }
}
