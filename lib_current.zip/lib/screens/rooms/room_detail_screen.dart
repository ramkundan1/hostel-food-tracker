import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../models/review.dart';
import '../../models/room_listing.dart';
import '../../services/firestore_service.dart';
import '../../services/user_provider.dart';
import '../../theme/app_theme.dart';
import '../../widgets/rating_stars.dart';
import '../../widgets/section_header.dart';

class RoomDetailScreen extends StatefulWidget {
  final RoomListing room;

  const RoomDetailScreen({super.key, required this.room});

  @override
  State<RoomDetailScreen> createState() => _RoomDetailScreenState();
}

class _RoomDetailScreenState extends State<RoomDetailScreen> {
  late RoomListing _room;
  List<Review> _reviews = [];
  bool _loadingReviews = true;

  @override
  void initState() {
    super.initState();
    _room = widget.room;
    _loadReviews();
  }

  Future<void> _loadReviews() async {
    final reviews = await context
        .read<FirestoreService>()
        .fetchReviews(ReviewTargetType.room, _room.id);

    if (mounted) {
      setState(() {
        _reviews = reviews;
        _loadingReviews = false;
      });
    }
  }

  Future<void> _toggleAvailability() async {
    final next = _room.availability == RoomAvailability.available
        ? RoomAvailability.occupied
        : RoomAvailability.available;

    await context.read<FirestoreService>().updateRoomAvailability(_room.id, next);

    setState(() {
      _room = RoomListing(
        id: _room.id,
        ownerId: _room.ownerId,
        ownerName: _room.ownerName,
        ownerPhone: _room.ownerPhone,
        title: _room.title,
        description: _room.description,
        price: _room.price,
        address: _room.address,
        photoUrls: _room.photoUrls,
        amenities: _room.amenities,
        availability: next,
        verified: _room.verified,
        avgRating: _room.avgRating,
        ratingCount: _room.ratingCount,
        createdAt: _room.createdAt,
      );
    });
  }

  void _openReviewSheet() {
    final user = context.read<UserProvider>().user;
    if (user == null) return;

    double rating = 4;
    final commentController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetContext) {
        return Padding(
          padding: EdgeInsets.only(
            left: 20,
            right: 20,
            top: 20,
            bottom: MediaQuery.of(sheetContext).viewInsets.bottom + 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Rate this room', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 12),
              Center(
                child: RatingBar.builder(
                  initialRating: rating,
                  minRating: 1,
                  itemSize: 34,
                  itemBuilder: (_, __) =>
                      const Icon(Icons.star_rounded, color: Colors.amber),
                  onRatingUpdate: (value) => rating = value,
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: commentController,
                maxLines: 3,
                decoration: const InputDecoration(hintText: 'Share your experience...'),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () async {
                  await context.read<FirestoreService>().submitReview(
                        Review(
                          id: '',
                          targetType: ReviewTargetType.room,
                          targetId: _room.id,
                          userId: user.uid,
                          userName: user.name,
                          rating: rating,
                          comment: commentController.text.trim(),
                          createdAt: DateTime.now(),
                        ),
                      );
                  if (context.mounted) Navigator.of(sheetContext).pop();
                  _loadReviews();
                },
                child: const Text('Submit Review'),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<UserProvider>().user;
    final isOwner = user != null && user.uid == _room.ownerId;
    final isAvailable = _room.availability == RoomAvailability.available;

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 240,
            pinned: true,
            backgroundColor: AppTheme.background,
            foregroundColor: AppTheme.textPrimary,
            flexibleSpace: FlexibleSpaceBar(
              background: _room.photoUrls.isNotEmpty
                  ? PageView(
                      children: _room.photoUrls
                          .map((url) => CachedNetworkImage(
                                imageUrl: url,
                                fit: BoxFit.cover,
                                placeholder: (_, __) =>
                                    Container(color: Colors.grey.shade200),
                              ))
                          .toList(),
                    )
                  : Container(
                      color: Colors.grey.shade200,
                      child: const Icon(Icons.home_rounded, size: 60, color: Colors.grey),
                    ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(_room.title,
                            style: Theme.of(context).textTheme.headlineSmall),
                      ),
                      if (_room.verified)
                        const Icon(Icons.verified_rounded, color: AppTheme.primary),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(_room.address, style: Theme.of(context).textTheme.bodyMedium),
                  const SizedBox(height: 12),
                  RatingStars(rating: _room.avgRating, count: _room.ratingCount, size: 18),
                  const SizedBox(height: 16),

                  // ---- Price + availability card ----
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFFEAECF0)),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.03),
                          blurRadius: 10,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              'Rs. ${_room.price.toStringAsFixed(0)} / month',
                              style: const TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                                color: AppTheme.primary,
                              ),
                            ),
                            const Spacer(),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(
                                color: isAvailable
                                    ? AppTheme.success
                                    : AppTheme.danger,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                isAvailable ? 'Available' : 'Occupied',
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600),
                              ),
                            ),
                          ],
                        ),
                        if (isOwner) ...[
                          const SizedBox(height: 12),
                          OutlinedButton.icon(
                            onPressed: _toggleAvailability,
                            icon: const Icon(Icons.sync_rounded),
                            label: Text(isAvailable
                                ? 'Mark as Occupied'
                                : 'Mark as Available'),
                          ),
                        ],
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),
                  SectionHeader(
                    icon: Icons.description_rounded,
                    label: 'Description',
                    color: AppTheme.primary,
                  ),
                  const SizedBox(height: 10),
                  Text(_room.description, style: Theme.of(context).textTheme.bodyMedium),

                  const SizedBox(height: 24),
                  SectionHeader(
                    icon: Icons.check_circle_rounded,
                    label: 'Amenities',
                    color: AppTheme.success,
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: _room.amenities.labels
                        .map((label) => Chip(
                              avatar: const Icon(Icons.check_rounded,
                                  size: 16, color: AppTheme.success),
                              label: Text(label),
                              backgroundColor: AppTheme.success.withOpacity(0.08),
                              side: BorderSide(
                                  color: AppTheme.success.withOpacity(0.25)),
                            ))
                        .toList(),
                  ),

                  const SizedBox(height: 24),
                  OutlinedButton.icon(
                    onPressed: () => launchUrl(Uri.parse('tel:${_room.ownerPhone}')),
                    icon: const Icon(Icons.call_rounded),
                    label: Text('Call ${_room.ownerName}'),
                  ),

                  const SizedBox(height: 28),
                  Row(
                    children: [
                      SectionHeader(
                        icon: Icons.reviews_rounded,
                        label: 'Reviews',
                        color: AppTheme.secondary,
                      ),
                      const Spacer(),
                      TextButton(
                        onPressed: _openReviewSheet,
                        child: const Text('Write a review'),
                      ),
                    ],
                  ),
                  if (_loadingReviews)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 20),
                      child: Center(child: CircularProgressIndicator()),
                    )
                  else if (_reviews.isEmpty)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      child: Text('No reviews yet — be the first.',
                          style: Theme.of(context).textTheme.bodyMedium),
                    )
                  else
                    ..._reviews.map((review) => _ReviewTile(review: review)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ReviewTile extends StatelessWidget {
  final Review review;

  const _ReviewTile({required this.review});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(review.userName, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(width: 8),
              RatingStars(rating: review.rating, count: 1, size: 14),
            ],
          ),
          if (review.comment.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(review.comment, style: Theme.of(context).textTheme.bodyMedium),
          ],
        ],
      ),
    );
  }
}
