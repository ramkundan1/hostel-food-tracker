import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/room_listing.dart';
import '../../services/firestore_service.dart';
import '../../services/user_provider.dart';
import '../../theme/app_theme.dart';
import '../../widgets/paginated_list_view.dart';
import '../../widgets/rating_stars.dart';
import 'add_room_screen.dart';
import 'room_detail_screen.dart';

class RoomsScreen extends StatefulWidget {
  const RoomsScreen({super.key});

  @override
  State<RoomsScreen> createState() => _RoomsScreenState();
}

class _RoomsScreenState extends State<RoomsScreen> {
  bool _onlyAvailable = false;
  int _listRebuildKey = 0;

  @override
  Widget build(BuildContext context) {
    final firestoreService = context.read<FirestoreService>();
    final user = context.watch<UserProvider>().user;

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Rent Rooms'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: FilterChip(
              label: const Text('Available only'),
              selected: _onlyAvailable,
              onSelected: (value) => setState(() {
                _onlyAvailable = value;
                _listRebuildKey++; // forces PaginatedListView to re-fetch
              }),
              selectedColor: AppTheme.success.withOpacity(0.15),
              checkmarkColor: AppTheme.success,
              labelStyle: TextStyle(
                color: _onlyAvailable ? AppTheme.success : AppTheme.textPrimary,
                fontWeight: FontWeight.w600,
                fontSize: 12.5,
              ),
              side: BorderSide(
                color: _onlyAvailable
                    ? AppTheme.success.withOpacity(0.4)
                    : const Color(0xFFD0D5DD),
              ),
            ),
          ),
        ],
      ),
      body: PaginatedListView<RoomListing>(
        key: ValueKey(_listRebuildKey),
        emptyMessage: 'No rooms listed yet.',
        fetchPage: (startAfter) => firestoreService.fetchRooms(
          startAfter: startAfter,
          onlyAvailable: _onlyAvailable,
        ),
        itemBuilder: (context, room) => _RoomCard(room: room),
      ),
      floatingActionButton: ((user?.isBusiness ?? false) || (user?.isAdmin ?? false))
          ? FloatingActionButton.extended(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const AddRoomScreen()),
              ),
              icon: const Icon(Icons.add_rounded),
              label: const Text('List a Room'),
            )
          : null,
    );
  }
}

class _RoomCard extends StatelessWidget {
  final RoomListing room;

  const _RoomCard({required this.room});

  @override
  Widget build(BuildContext context) {
    final isAvailable = room.availability == RoomAvailability.available;
    final amenityLabels = room.amenities.labels;

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFEAECF0)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => RoomDetailScreen(room: room)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                AspectRatio(
                  aspectRatio: 16 / 9,
                  child: room.photoUrls.isNotEmpty
                      ? CachedNetworkImage(
                          imageUrl: room.photoUrls.first,
                          fit: BoxFit.cover,
                          placeholder: (_, __) => Container(color: Colors.grey.shade200),
                          errorWidget: (_, __, ___) => Container(
                            color: Colors.grey.shade200,
                            child: const Icon(Icons.home_rounded, color: Colors.grey),
                          ),
                        )
                      : Container(
                          color: Colors.grey.shade100,
                          child: Icon(Icons.home_rounded,
                              color: Colors.grey.shade300, size: 44),
                        ),
                ),
                Positioned(
                  top: 10,
                  left: 10,
                  child: _Badge(
                    text: isAvailable ? 'Available' : 'Occupied',
                    color: isAvailable ? AppTheme.success : AppTheme.danger,
                  ),
                ),
                if (room.verified)
                  const Positioned(
                    top: 10,
                    right: 10,
                    child: _Badge(
                      text: 'Verified',
                      color: AppTheme.primary,
                      icon: Icons.verified_rounded,
                    ),
                  ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(room.title, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.place_rounded, size: 13, color: Colors.grey.shade500),
                      const SizedBox(width: 3),
                      Expanded(
                        child: Text(room.address,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.bodyMedium),
                      ),
                    ],
                  ),
                  if (amenityLabels.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: amenityLabels
                          .take(3)
                          .map((label) => Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 3),
                                decoration: BoxDecoration(
                                  color: AppTheme.background,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  label,
                                  style: TextStyle(
                                      fontSize: 11, color: Colors.grey.shade700),
                                ),
                              ))
                          .toList(),
                    ),
                  ],
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Text(
                        'Rs. ${room.price.toStringAsFixed(0)}/mo',
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 15,
                          color: AppTheme.primary,
                        ),
                      ),
                      const Spacer(),
                      RatingStars(rating: room.avgRating, count: room.ratingCount),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final String text;
  final Color color;
  final IconData? icon;

  const _Badge({required this.text, required this.color, this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(9),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.35),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, color: Colors.white, size: 12),
            const SizedBox(width: 4),
          ],
          Text(
            text,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}
