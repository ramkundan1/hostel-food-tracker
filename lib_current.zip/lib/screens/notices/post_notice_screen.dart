import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/notice.dart';
import '../../services/firestore_service.dart';
import '../../services/storage_service.dart';
import '../../services/user_provider.dart';

class PostNoticeScreen extends StatefulWidget {
  const PostNoticeScreen({super.key});

  @override
  State<PostNoticeScreen> createState() => _PostNoticeScreenState();
}

class _PostNoticeScreenState extends State<PostNoticeScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();

  File? _attachedFile;
  String? _attachedFileName;
  bool _busy = false;

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _pickFile() async {
    // file_picker 12+ dropped FilePicker.platform in favor of static
    // methods that return a plain List<PlatformFile> directly (no
    // more nullable FilePickerResult wrapper) — empty list means
    // the user canceled.
    final files = await FilePicker.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );
    if (files.isEmpty || files.first.path == null) return;

    setState(() {
      _attachedFile = File(files.first.path!);
      _attachedFileName = files.first.name;
    });
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _busy = true);

    try {
      String? fileUrl;

      if (_attachedFile != null) {
        fileUrl = await context.read<StorageService>().uploadNoticeFile(
              file: _attachedFile!,
              fileName: '${DateTime.now().millisecondsSinceEpoch}_$_attachedFileName',
            );
      }

      final user = context.read<UserProvider>().user!;

      await context.read<FirestoreService>().postNotice(
            Notice(
              id: '',
              title: _titleController.text.trim(),
              description: _descriptionController.text.trim(),
              fileUrl: fileUrl,
              postedByName: user.name,
              postedAt: DateTime.now(),
            ),
          );

      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Failed to post: $e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Post Notice')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextFormField(
                  controller: _titleController,
                  decoration: const InputDecoration(labelText: 'Title'),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                ),
                const SizedBox(height: 14),
                TextFormField(
                  controller: _descriptionController,
                  maxLines: 5,
                  decoration: const InputDecoration(labelText: 'Description'),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                ),
                const SizedBox(height: 14),
                OutlinedButton.icon(
                  onPressed: _pickFile,
                  icon: const Icon(Icons.attach_file_rounded),
                  label: Text(_attachedFileName ?? 'Attach PDF (optional)'),
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _busy ? null : _submit,
                  child: _busy
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white),
                        )
                      : const Text('Post Notice'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
