import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../models/notice.dart';
import '../../services/firestore_service.dart';
import '../../services/user_provider.dart';
import '../../theme/app_theme.dart';
import '../../widgets/paginated_list_view.dart';
import '../../widgets/section_header.dart';
import 'in_app_webview_screen.dart';
import 'post_notice_screen.dart';

class NoticesScreen extends StatefulWidget {
  const NoticesScreen({super.key});

  @override
  State<NoticesScreen> createState() => _NoticesScreenState();
}

class _NoticesScreenState extends State<NoticesScreen> {
  final GlobalKey<State> _listKey = GlobalKey<State>();

  // Official campus/TU notice pages — quick links out to the real
  // sources, sitting alongside (not replacing) the in-app feed
  // below, since posting is still done manually via "Post Notice".
  // Exam notices get their own accent color so they read visually
  // distinct from the four campus boards.
  static const List<_ExternalSource> _officialSources = [
    _ExternalSource('Purwanchal Campus', 'https://www.ioepc.edu.np/info/category/notice/', Icons.school_rounded, AppTheme.primary),
    _ExternalSource('Pulchowk Campus', 'https://pcampus.edu.np/category/general-notices/', Icons.school_rounded, AppTheme.primary),
    _ExternalSource('Thapathali Campus', 'https://tcioe.edu.np/notices', Icons.school_rounded, AppTheme.primary),
    _ExternalSource('Paschimanchal Campus', 'https://ioepas.edu.np/category/news-notices', Icons.school_rounded, AppTheme.primary),
    _ExternalSource('TU Exam Notices', 'https://tu.edu.np/notices', Icons.assignment_rounded, AppTheme.secondary),
  ];

  @override
  Widget build(BuildContext context) {
    final firestoreService = context.read<FirestoreService>();
    final user = context.watch<UserProvider>().user;

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(title: const Text('Notices')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
            child: SectionHeader(
              icon: Icons.public_rounded,
              label: 'Official Notice Boards',
              color: AppTheme.primary,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 2.6,
              children: _officialSources
                  .map((source) => _SourceCard(source: source))
                  .toList(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
            child: SectionHeader(
              icon: Icons.campaign_rounded,
              label: 'Campus Connect Announcements',
              color: AppTheme.secondary,
            ),
          ),
          Expanded(
            child: PaginatedListView<Notice>(
              key: _listKey,
              emptyMessage: 'No notices yet. Check back soon!',
              fetchPage: (startAfter) =>
                  firestoreService.fetchNotices(startAfter: startAfter),
              itemBuilder: (context, notice) => _NoticeCard(notice: notice),
            ),
          ),
        ],
      ),
      floatingActionButton: (user?.isAdmin ?? false)
          ? FloatingActionButton.extended(
              onPressed: () async {
                await Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const PostNoticeScreen()),
                );
                setState(() {}); // refresh list on return
              },
              icon: const Icon(Icons.add_rounded),
              label: const Text('Post Notice'),
            )
          : null,
    );
  }
}

class _ExternalSource {
  final String label;
  final String url;
  final IconData icon;
  final Color color;

  const _ExternalSource(this.label, this.url, this.icon, this.color);
}

class _SourceCard extends StatelessWidget {
  final _ExternalSource source;

  const _SourceCard({required this.source});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => InAppWebViewScreen(
              url: source.url,
              title: source.label,
            ),
          ),
        ),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFEAECF0)),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: source.color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(source.icon, color: source.color, size: 18),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  source.label,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 12.5,
                    height: 1.2,
                  ),
                ),
              ),
              Icon(Icons.chevron_right_rounded,
                  size: 18, color: Colors.grey.shade400),
            ],
          ),
        ),
      ),
    );
  }
}

class _NoticeCard extends StatelessWidget {
  final Notice notice;

  const _NoticeCard({required this.notice});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFEAECF0)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Colored accent strip — a quick visual cue this is an
            // in-app (admin-posted) notice, distinct from the
            // official-source cards above.
            Container(
              width: 4,
              decoration: const BoxDecoration(
                color: AppTheme.secondary,
                borderRadius: BorderRadius.horizontal(
                  left: Radius.circular(16),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: AppTheme.primary.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(Icons.campaign_rounded,
                              color: AppTheme.primary, size: 20),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(notice.title,
                              style: Theme.of(context).textTheme.titleMedium),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text(notice.description,
                        style: Theme.of(context).textTheme.bodyMedium),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Icon(Icons.schedule_rounded,
                            size: 13, color: Colors.grey.shade500),
                        const SizedBox(width: 4),
                        Text(
                          DateFormat('MMM d, yyyy').format(notice.postedAt),
                          style: TextStyle(
                              color: Colors.grey.shade500, fontSize: 12),
                        ),
                        const Spacer(),
                        if (notice.fileUrl != null)
                          TextButton.icon(
                            onPressed: () =>
                                launchUrl(Uri.parse(notice.fileUrl!)),
                            style: TextButton.styleFrom(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 4),
                              visualDensity: VisualDensity.compact,
                            ),
                            icon: const Icon(Icons.attach_file_rounded,
                                size: 15),
                            label: const Text('Attachment',
                                style: TextStyle(fontSize: 12.5)),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
