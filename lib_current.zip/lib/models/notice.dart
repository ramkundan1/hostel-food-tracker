class Notice {
  final String id;
  final String title;
  final String description;
  final String? fileUrl;
  final String postedByName;
  final DateTime postedAt;

  Notice({
    required this.id,
    required this.title,
    required this.description,
    this.fileUrl,
    required this.postedByName,
    required this.postedAt,
  });

  factory Notice.fromMap(String id, Map<String, dynamic> map) {
    return Notice(
      id: id,
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      fileUrl: map['fileUrl'],
      postedByName: map['postedByName'] ?? 'Campus Admin',
      postedAt: map['postedAt'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['postedAt'])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'description': description,
      'fileUrl': fileUrl,
      'postedByName': postedByName,
      'postedAt': postedAt.millisecondsSinceEpoch,
    };
  }
}
