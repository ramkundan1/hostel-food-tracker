enum ExamType { regular, back }

ExamType examTypeFromString(String value) =>
    value == 'back' ? ExamType.back : ExamType.regular;

String examTypeToString(ExamType type) =>
    type == ExamType.back ? 'back' : 'regular';

class ExamPaper {
  final String id;
  final ExamType examType;
  final DateTime examDate; // the date section this paper belongs under
  final String subject;
  final String semester;
  final String fileUrl;
  final String fileName;
  final bool verified;
  final DateTime uploadedAt;

  ExamPaper({
    required this.id,
    required this.examType,
    required this.examDate,
    required this.subject,
    required this.semester,
    required this.fileUrl,
    required this.fileName,
    required this.verified,
    required this.uploadedAt,
  });

  factory ExamPaper.fromMap(String id, Map<String, dynamic> map) {
    return ExamPaper(
      id: id,
      examType: examTypeFromString(map['examType'] ?? 'regular'),
      examDate: map['examDate'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['examDate'])
          : DateTime.now(),
      subject: map['subject'] ?? '',
      semester: map['semester'] ?? '',
      fileUrl: map['fileUrl'] ?? '',
      fileName: map['fileName'] ?? 'paper.pdf',
      verified: map['verified'] ?? false,
      uploadedAt: map['uploadedAt'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['uploadedAt'])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'examType': examTypeToString(examType),
      'examDate': examDate.millisecondsSinceEpoch,
      'subject': subject,
      'semester': semester,
      'fileUrl': fileUrl,
      'fileName': fileName,
      'verified': verified,
      'uploadedAt': uploadedAt.millisecondsSinceEpoch,
    };
  }
}
