import 'package:cloud_firestore/cloud_firestore.dart';

/// Pairs a page of items with the raw Firestore document to pass
/// as `startAfter` on the next fetch. Keeping this generic means
/// PaginatedListView doesn't need to know anything about Notice,
/// RoomListing, etc. — same widget, any collection.
class PageResult<T> {
  final List<T> items;
  final DocumentSnapshot? lastDoc;
  final bool hasMore;

  PageResult({
    required this.items,
    required this.lastDoc,
    required this.hasMore,
  });
}
