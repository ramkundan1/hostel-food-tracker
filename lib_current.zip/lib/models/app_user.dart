enum UserRole { student, business, admin }

UserRole userRoleFromString(String value) {
  switch (value) {
    case 'business':
      return UserRole.business;
    case 'admin':
      return UserRole.admin;
    case 'student':
    default:
      return UserRole.student;
  }
}

String userRoleToString(UserRole role) {
  switch (role) {
    case UserRole.business:
      return 'business';
    case UserRole.admin:
      return 'admin';
    case UserRole.student:
      return 'student';
  }
}

class AppUser {
  final String uid;
  final String name;
  final String email;
  final String? phone;
  final String? photoUrl;
  final UserRole role;
  final DateTime createdAt;

  AppUser({
    required this.uid,
    required this.name,
    required this.email,
    this.phone,
    this.photoUrl,
    required this.role,
    required this.createdAt,
  });

  bool get isBusiness => role == UserRole.business;
  bool get isAdmin => role == UserRole.admin;

  factory AppUser.fromMap(String uid, Map<String, dynamic> map) {
    return AppUser(
      uid: uid,
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      phone: map['phone'],
      photoUrl: map['photoUrl'],
      role: userRoleFromString(map['role'] ?? 'student'),
      createdAt: map['createdAt'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['createdAt'])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'phone': phone,
      'photoUrl': photoUrl,
      'role': userRoleToString(role),
      'createdAt': createdAt.millisecondsSinceEpoch,
    };
  }
}
