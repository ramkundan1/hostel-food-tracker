enum ReviewTargetType { room, restaurant }

class Review {
  final String id;
  final ReviewTargetType targetType;
  final String targetId;
  final String userId;
  final String userName;
  final double rating; // 1.0 - 5.0
  final String comment;
  final DateTime createdAt;

  Review({
    required this.id,
    required this.targetType,
    required this.targetId,
    required this.userId,
    required this.userName,
    required this.rating,
    required this.comment,
    required this.createdAt,
  });

  factory Review.fromMap(String id, Map<String, dynamic> map) {
    return Review(
      id: id,
      targetType:
          map['targetType'] == 'restaurant'
              ? ReviewTargetType.restaurant
              : ReviewTargetType.room,
      targetId: map['targetId'] ?? '',
      userId: map['userId'] ?? '',
      userName: map['userName'] ?? '',
      rating: (map['rating'] ?? 0).toDouble(),
      comment: map['comment'] ?? '',
      createdAt: map['createdAt'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['createdAt'])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'targetType':
          targetType == ReviewTargetType.restaurant ? 'restaurant' : 'room',
      'targetId': targetId,
      'userId': userId,
      'userName': userName,
      'rating': rating,
      'comment': comment,
      'createdAt': createdAt.millisecondsSinceEpoch,
    };
  }
}
