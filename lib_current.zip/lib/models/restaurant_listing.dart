class RestaurantListing {
  final String id;
  final String ownerId;
  final String name;
  final String description;
  final String address;
  final String phone;
  final List<String> photoUrls;
  final List<String> cuisineTags;
  final bool verified;
  final double avgRating;
  final int ratingCount;
  final DateTime createdAt;

  RestaurantListing({
    required this.id,
    required this.ownerId,
    required this.name,
    required this.description,
    required this.address,
    required this.phone,
    required this.photoUrls,
    required this.cuisineTags,
    required this.verified,
    required this.avgRating,
    required this.ratingCount,
    required this.createdAt,
  });

  factory RestaurantListing.fromMap(String id, Map<String, dynamic> map) {
    return RestaurantListing(
      id: id,
      ownerId: map['ownerId'] ?? '',
      name: map['name'] ?? '',
      description: map['description'] ?? '',
      address: map['address'] ?? '',
      phone: map['phone'] ?? '',
      photoUrls: List<String>.from(map['photoUrls'] ?? []),
      cuisineTags: List<String>.from(map['cuisineTags'] ?? []),
      verified: map['verified'] ?? false,
      avgRating: (map['avgRating'] ?? 0).toDouble(),
      ratingCount: map['ratingCount'] ?? 0,
      createdAt: map['createdAt'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['createdAt'])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'ownerId': ownerId,
      'name': name,
      'description': description,
      'address': address,
      'phone': phone,
      'photoUrls': photoUrls,
      'cuisineTags': cuisineTags,
      'verified': verified,
      'avgRating': avgRating,
      'ratingCount': ratingCount,
      'createdAt': createdAt.millisecondsSinceEpoch,
    };
  }
}
