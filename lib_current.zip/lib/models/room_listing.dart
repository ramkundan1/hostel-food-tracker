enum RoomAvailability { available, occupied }

class RoomAmenities {
  final bool water;
  final bool internet;
  final bool attachedBathroom;
  final bool kitchen;
  final bool parking;
  final bool electricityIncluded;

  const RoomAmenities({
    this.water = false,
    this.internet = false,
    this.attachedBathroom = false,
    this.kitchen = false,
    this.parking = false,
    this.electricityIncluded = false,
  });

  factory RoomAmenities.fromMap(Map<String, dynamic>? map) {
    if (map == null) return const RoomAmenities();
    return RoomAmenities(
      water: map['water'] ?? false,
      internet: map['internet'] ?? false,
      attachedBathroom: map['attachedBathroom'] ?? false,
      kitchen: map['kitchen'] ?? false,
      parking: map['parking'] ?? false,
      electricityIncluded: map['electricityIncluded'] ?? false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'water': water,
      'internet': internet,
      'attachedBathroom': attachedBathroom,
      'kitchen': kitchen,
      'parking': parking,
      'electricityIncluded': electricityIncluded,
    };
  }

  /// Used to render a chip list in the UI without repeating this
  /// switch-like logic in every screen that shows a room card.
  List<String> get labels {
    final List<String> result = [];
    if (water) result.add('Water');
    if (internet) result.add('Internet');
    if (attachedBathroom) result.add('Attached Bathroom');
    if (kitchen) result.add('Kitchen');
    if (parking) result.add('Parking');
    if (electricityIncluded) result.add('Electricity Included');
    return result;
  }
}

class RoomListing {
  final String id;
  final String ownerId;
  final String ownerName;
  final String ownerPhone;
  final String title;
  final String description;
  final double price;
  final String address;
  final List<String> photoUrls;
  final RoomAmenities amenities;
  final RoomAvailability availability;
  final bool verified;
  final double avgRating;
  final int ratingCount;
  final DateTime createdAt;

  RoomListing({
    required this.id,
    required this.ownerId,
    required this.ownerName,
    required this.ownerPhone,
    required this.title,
    required this.description,
    required this.price,
    required this.address,
    required this.photoUrls,
    required this.amenities,
    required this.availability,
    required this.verified,
    required this.avgRating,
    required this.ratingCount,
    required this.createdAt,
  });

  factory RoomListing.fromMap(String id, Map<String, dynamic> map) {
    return RoomListing(
      id: id,
      ownerId: map['ownerId'] ?? '',
      ownerName: map['ownerName'] ?? '',
      ownerPhone: map['ownerPhone'] ?? '',
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      price: (map['price'] ?? 0).toDouble(),
      address: map['address'] ?? '',
      photoUrls: List<String>.from(map['photoUrls'] ?? []),
      amenities: RoomAmenities.fromMap(map['amenities']),
      availability: map['availability'] == 'occupied'
          ? RoomAvailability.occupied
          : RoomAvailability.available,
      verified: map['verified'] ?? false,
      avgRating: (map['avgRating'] ?? 0).toDouble(),
      ratingCount: map['ratingCount'] ?? 0,
      createdAt: map['createdAt'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['createdAt'])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'ownerId': ownerId,
      'ownerName': ownerName,
      'ownerPhone': ownerPhone,
      'title': title,
      'description': description,
      'price': price,
      'address': address,
      'photoUrls': photoUrls,
      'amenities': amenities.toMap(),
      'availability':
          availability == RoomAvailability.occupied ? 'occupied' : 'available',
      'verified': verified,
      'avgRating': avgRating,
      'ratingCount': ratingCount,
      'createdAt': createdAt.millisecondsSinceEpoch,
    };
  }
}
