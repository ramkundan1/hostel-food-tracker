import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';

import 'firebase_options.dart';
import 'theme/app_theme.dart';
import 'services/auth_service.dart';
import 'services/firestore_service.dart';
import 'services/storage_service.dart';
import 'services/user_provider.dart';
import 'screens/auth/welcome_screen.dart';
import 'screens/home_shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const CampusConnectApp());
}

class CampusConnectApp extends StatelessWidget {
  const CampusConnectApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider<AuthService>(create: (_) => AuthService()),
        Provider<FirestoreService>(create: (_) => FirestoreService()),
        Provider<StorageService>(create: (_) => StorageService()),
        ChangeNotifierProxyProvider<AuthService, UserProvider>(
          create: (context) => UserProvider(context.read<AuthService>()),
          update: (context, authService, previous) =>
              previous ?? UserProvider(authService),
        ),
      ],
      child: MaterialApp(
        title: 'Campus Connect',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.theme,
        home: const AuthGate(),
      ),
    );
  }
}

/// Decides which top-level screen to show based on sign-in state.
/// This is the ONLY place that branches on "is someone logged in?"
/// — every other screen assumes a UserProvider.user already exists.
///
/// Three states, not two: no Firebase Auth user (WelcomeScreen);
/// signed in but the Firestore profile hasn't loaded yet, whether
/// still loading or it failed (a dedicated screen with a Retry
/// button — never silently reverts to WelcomeScreen, which is what
/// caused the "successfully logged in but stuck on login" bug);
/// and fully loaded (HomeShell).
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<UserProvider>(
      builder: (context, userProvider, _) {
        if (!userProvider.isSignedIn) {
          return const WelcomeScreen();
        }

        if (userProvider.user != null) {
          return const HomeShell();
        }

        return Scaffold(
          body: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (userProvider.profileError == null) ...[
                    const CircularProgressIndicator(),
                    const SizedBox(height: 16),
                    const Text('Setting things up...'),
                  ] else ...[
                    Icon(Icons.wifi_off_rounded,
                        size: 40, color: Colors.grey.shade400),
                    const SizedBox(height: 16),
                    Text(
                      userProvider.profileError!,
                      textAlign: TextAlign.center,
                    ),
                  ],
                  const SizedBox(height: 20),
                  // Always available, not just on error — if this
                  // is ever slow for any reason, the user has an
                  // immediate manual way out instead of just
                  // waiting and hoping.
                  OutlinedButton(
                    onPressed: () => userProvider.retryLoadProfile(),
                    child: const Text('Retry'),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
