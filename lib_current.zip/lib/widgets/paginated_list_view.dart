import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../models/page_result.dart';
import 'list_skeleton.dart';

/// Generic infinite-scroll list backed by any Firestore-cursor-based
/// fetch function. Handles: first-load shimmer, pull-to-refresh,
/// load-more-on-scroll, an empty state, and an error state with
/// retry — once, here, instead of reimplementing this per screen.
class PaginatedListView<T> extends StatefulWidget {
  final Future<PageResult<T>> Function(DocumentSnapshot? startAfter) fetchPage;
  final Widget Function(BuildContext context, T item) itemBuilder;
  final String emptyMessage;
  final EdgeInsets padding;

  const PaginatedListView({
    super.key,
    required this.fetchPage,
    required this.itemBuilder,
    this.emptyMessage = 'Nothing here yet.',
    this.padding = const EdgeInsets.all(16),
  });

  @override
  State<PaginatedListView<T>> createState() => _PaginatedListViewState<T>();
}

class _PaginatedListViewState<T> extends State<PaginatedListView<T>> {
  final List<T> _items = [];
  final ScrollController _scrollController = ScrollController();

  DocumentSnapshot? _cursor;
  bool _initialLoading = true;
  bool _loadingMore = false;
  bool _hasMore = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadFirstPage();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (!_hasMore || _loadingMore || _initialLoading) return;

    final threshold = _scrollController.position.maxScrollExtent - 300;
    if (_scrollController.position.pixels >= threshold) {
      _loadNextPage();
    }
  }

  Future<void> _loadFirstPage() async {
    setState(() {
      _initialLoading = true;
      _error = null;
    });

    try {
      final result = await widget.fetchPage(null);
      setState(() {
        _items
          ..clear()
          ..addAll(result.items);
        _cursor = result.lastDoc;
        _hasMore = result.hasMore;
        _initialLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Failed to load — pull down to retry.';
        _initialLoading = false;
      });
    }
  }

  Future<void> _loadNextPage() async {
    setState(() => _loadingMore = true);

    try {
      final result = await widget.fetchPage(_cursor);
      setState(() {
        _items.addAll(result.items);
        _cursor = result.lastDoc;
        _hasMore = result.hasMore;
        _loadingMore = false;
      });
    } catch (e) {
      setState(() => _loadingMore = false);
      // Silent-ish failure on load-more: the user already has
      // content on screen, no need for a jarring full-screen error
      // over a pagination hiccup. They can just scroll again.
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_initialLoading) {
      return const ListSkeleton();
    }

    if (_error != null) {
      return RefreshIndicator(
        onRefresh: _loadFirstPage,
        child: ListView(
          children: [
            const SizedBox(height: 120),
            Icon(Icons.wifi_off_rounded, size: 40, color: Colors.grey.shade400),
            const SizedBox(height: 12),
            Center(
              child: Text(_error!, style: TextStyle(color: Colors.grey.shade600)),
            ),
          ],
        ),
      );
    }

    if (_items.isEmpty) {
      return RefreshIndicator(
        onRefresh: _loadFirstPage,
        child: ListView(
          children: [
            const SizedBox(height: 140),
            Icon(Icons.inbox_rounded, size: 40, color: Colors.grey.shade400),
            const SizedBox(height: 12),
            Center(
              child: Text(
                widget.emptyMessage,
                style: TextStyle(color: Colors.grey.shade600),
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadFirstPage,
      child: ListView.separated(
        controller: _scrollController,
        padding: widget.padding,
        itemCount: _items.length + (_hasMore ? 1 : 0),
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          if (index >= _items.length) {
            return const Padding(
              padding: EdgeInsets.symmetric(vertical: 20),
              child: Center(
                child: SizedBox(
                  height: 22,
                  width: 22,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              ),
            );
          }

          return widget.itemBuilder(context, _items[index]);
        },
      ),
    );
  }
}
