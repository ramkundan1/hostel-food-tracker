import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

/// A row of skeleton cards shown while the first page of a list is
/// loading. This — plus pagination in FirestoreService — is the
/// other half of "the app shouldn't feel laggy": the user sees an
/// immediate, correctly-shaped placeholder instead of a spinner
/// that pops into a totally different layout once data arrives.
class ListSkeleton extends StatelessWidget {
  final int itemCount;
  final double itemHeight;

  const ListSkeleton({super.key, this.itemCount = 6, this.itemHeight = 96});

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: Colors.grey.shade200,
      highlightColor: Colors.grey.shade100,
      child: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: itemCount,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (_, __) => Container(
          height: itemHeight,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),
    );
  }
}
