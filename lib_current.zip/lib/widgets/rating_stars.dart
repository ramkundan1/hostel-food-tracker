import 'package:flutter/material.dart';

/// Read-only star display, e.g. "4.3 (28)" next to a listing.
class RatingStars extends StatelessWidget {
  final double rating;
  final int count;
  final double size;

  const RatingStars({
    super.key,
    required this.rating,
    required this.count,
    this.size = 16,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(Icons.star_rounded, color: Colors.amber, size: size),
        const SizedBox(width: 4),
        Text(
          count == 0 ? 'New' : rating.toStringAsFixed(1),
          style: TextStyle(fontWeight: FontWeight.w600, fontSize: size * 0.8),
        ),
        if (count > 0) ...[
          const SizedBox(width: 4),
          Text(
            '($count)',
            style: TextStyle(color: Colors.grey.shade600, fontSize: size * 0.75),
          ),
        ],
      ],
    );
  }
}
