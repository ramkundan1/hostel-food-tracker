import 'package:flutter/material.dart';

/// Colored accent bar + icon + bold label — the section-divider
/// pattern established on the Notices screen, shared so every
/// screen (Rooms, Restaurants, Profile, ...) looks consistent
/// instead of each one rolling its own version.
class SectionHeader extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;

  const SectionHeader({
    super.key,
    required this.icon,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 18,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 8),
        Icon(icon, size: 17, color: color),
        const SizedBox(width: 6),
        Text(
          label,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontSize: 15,
                fontWeight: FontWeight.w700,
              ),
        ),
      ],
    );
  }
}
